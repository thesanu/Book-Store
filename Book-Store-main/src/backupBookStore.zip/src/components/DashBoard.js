import React from 'react'

function DashBoard() {
  return (
    <div>
      <h1>welcome to DashBoard</h1>
    </div>
  )
}
export default DashBoard